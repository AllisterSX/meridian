import { discoverPools, getPoolDetail, getTopCandidates } from "./screening.js";
import {
  getActiveBin,
  deployPosition,
  getMyPositions,
  getWalletPositions,
  getPositionPnl,
  claimFees,
  closePosition,
  searchPools,
  withdrawLiquidity,
  addLiquidity,
} from "./dlmm.js";
import { getWalletBalances, swapToken } from "./wallet.js";
import { studyTopLPers, getPoolInfo } from "./study.js";
import { addLesson, clearAllLessons, clearPerformance, removeLessonsByKeyword, getPerformanceHistory, pinLesson, unpinLesson, listLessons } from "../lessons.js";
import { setPositionInstruction } from "../state.js";
import { getPoolMemory, addPoolNote } from "../pool-memory.js";
import { addStrategy, listStrategies, getStrategy, setActiveStrategy, removeStrategy } from "../strategy-library.js";
import { addToBlacklist, removeFromBlacklist, listBlacklist } from "../token-blacklist.js";
import { addSmartWallet, removeSmartWallet, listSmartWallets, checkSmartWalletsOnPool } from "../smart-wallets.js";
import { getTokenInfo, getTokenHolders, getTokenNarrative } from "./token.js";
import { config, reloadScreeningThresholds } from "../config.js";
import { updateStagedSignals, getPoolForMint } from "../signal-tracker.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { execSync, spawn } from "child_process";
import { CONFIG_KEY_MAP, getRequiredSolBalance } from "../runtime-helpers.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const USER_CONFIG_PATH = path.join(__dirname, "../user-config.json");
import { log, logAction } from "../logger.js";
import { rememberFact, recallMemory, forgetFact } from "../memory.js";
import { emit } from "../notifier.js";
import { notifyDeploy, notifyClose, notifySwap } from "../telegram.js";
import { invalidateWalletCache } from "../agent.js";

// Registered by index.js so update_config can restart cron jobs when intervals change
let _cronRestarter = null;
export function registerCronRestarter(fn) { _cronRestarter = fn; }

// Map tool names to implementations
const toolMap = {
  discover_pools: discoverPools,
  get_top_candidates: getTopCandidates,
  get_pool_detail: getPoolDetail,
get_position_pnl: async (args) => {
    const result = await getPositionPnl(args);
    if (!result || result.error) return result;

    // ── HARD STOP LOSS: auto-force close if SL threshold hit ─────────────────
    // This fires even if LLM decides to ignore the SL rule in its reasoning.
    // emergencyPriceDropPct is stored as a negative number e.g. -50
    const slThreshold = config.management.emergencyPriceDropPct ?? -50;
    const pnlPct = result.pnl_pct ?? result.pnl?.pnl_pct ?? null;
    const posAddr = args.position_address;

    if (pnlPct !== null && slThreshold < 0 && pnlPct <= slThreshold) {
      log("safety", `HARD SL TRIGGERED: position ${posAddr?.slice(0,8)} PnL ${pnlPct}% <= threshold ${slThreshold}% — forcing close`);
      try {
        const closeResult = await closePosition({ position_address: posAddr });
        log("safety", `Hard SL close result: ${JSON.stringify(closeResult).slice(0,200)}`);
        // Attach SL flag so executor's post-close auto-swap still fires
        return {
          ...result,
          _hard_sl_triggered: true,
          _sl_close_result: closeResult,
          warning: `HARD STOP LOSS TRIGGERED: PnL ${pnlPct}% hit threshold ${slThreshold}%. Position closed automatically.`,
        };
      } catch (e) {
        log("error", `Hard SL close failed for ${posAddr?.slice(0,8)}: ${e.message}`);
        return { ...result, warning: `HARD SL: close attempt failed — ${e.message}. Close manually.` };
      }
    }

    // ── HARD TAKE PROFIT: auto-close if unclaimed fees >= takeProfitFeePct ──
    const tpPct = config.management.takeProfitFeePct ?? 5;
    const deployedUsd = result.initial_value_usd ?? result.deposited_value_usd ?? 0;
    const unclaimedUsd = result.unclaimed_fees_usd ?? result.fees?.unclaimed_usd ?? 0;
    const feePct = deployedUsd > 0 ? (unclaimedUsd / deployedUsd) * 100 : 0;

    if (tpPct > 0 && feePct >= tpPct && deployedUsd > 0) {
      log("safety", `HARD TP TRIGGERED: position ${posAddr?.slice(0,8)} fees ${feePct.toFixed(2)}% >= threshold ${tpPct}% — forcing close`);
      try {
        const closeResult = await closePosition({ position_address: posAddr });
        log("safety", `Hard TP close result: ${JSON.stringify(closeResult).slice(0,200)}`);
        return {
          ...result,
          _hard_tp_triggered: true,
          _tp_close_result: closeResult,
          warning: `HARD TAKE PROFIT TRIGGERED: fees ${feePct.toFixed(2)}% hit threshold ${tpPct}%. Position closed automatically.`,
        };
      } catch (e) {
        log("error", `Hard TP close failed for ${posAddr?.slice(0,8)}: ${e.message}`);
        return { ...result, warning: `HARD TP: close attempt failed — ${e.message}. Close manually.` };
      }
    }

    return result;
  },
  get_active_bin: getActiveBin,
  deploy_position: deployPosition,
  get_my_positions: getMyPositions,
  get_wallet_positions: getWalletPositions,
  search_pools: searchPools,
  get_token_info: getTokenInfo,
  get_token_holders: getTokenHolders,
  get_token_narrative: getTokenNarrative,
  add_smart_wallet: addSmartWallet,
  remove_smart_wallet: removeSmartWallet,
  list_smart_wallets: listSmartWallets,
  check_smart_wallets_on_pool: checkSmartWalletsOnPool,
  claim_fees: claimFees,
  close_position: closePosition,
  get_wallet_balance: getWalletBalances,
  swap_token: swapToken,
  get_top_lpers: studyTopLPers,
  study_top_lpers: studyTopLPers,
  get_pool_info: getPoolInfo,
  get_pool_memory: getPoolMemory,
  withdraw_liquidity: withdrawLiquidity,
  add_liquidity: addLiquidity,
  add_pool_note: addPoolNote,
  add_strategy: addStrategy,
  list_strategies: listStrategies,
  get_strategy: getStrategy,
  set_active_strategy: setActiveStrategy,
  remove_strategy: removeStrategy,
  add_to_blacklist: addToBlacklist,
  remove_from_blacklist: removeFromBlacklist,
  list_blacklist: listBlacklist,
  get_performance_history: getPerformanceHistory,
  calculate_bins: ({ bin_step, price_range_pct, bin_count }) => {
    if (!bin_step || bin_step <= 0) return { error: "bin_step is required and must be > 0" };
    const stepPct = bin_step / 10000; // e.g. 100 → 0.01 (1%)
    if (price_range_pct != null) {
      // Convert % range to bin count
      const pct = Math.abs(price_range_pct) / 100;
      const bins = Math.abs(Math.ceil(Math.log(1 - pct) / Math.log(1 + stepPct)));
      const actualPct = (1 - Math.pow(1 + stepPct, -bins)) * 100;
      return { bin_step, price_range_pct: Math.abs(price_range_pct), bins_needed: bins, actual_range_pct: Math.round(actualPct * 100) / 100, wide_range: bins > 69, per_bin_pct: Math.round(stepPct * 10000) / 100 };
    }
    if (bin_count != null) {
      // Convert bin count to % range
      const pct = (1 - Math.pow(1 + stepPct, -bin_count)) * 100;
      return { bin_step, bin_count, range_pct: Math.round(pct * 100) / 100, wide_range: bin_count > 69, per_bin_pct: Math.round(stepPct * 10000) / 100 };
    }
    // Just show per-bin info
    return { bin_step, per_bin_pct: Math.round(stepPct * 10000) / 100, example_50pct_bins: Math.ceil(Math.log(0.5) / Math.log(1 + stepPct)) };
  },
  pin_lesson: ({ id }) => pinLesson(id),
  unpin_lesson: ({ id }) => unpinLesson(id),
  list_lessons: ({ role, pinned, tag, limit } = {}) => listLessons({ role, pinned, tag, limit }),
  set_position_note: ({ position_address, instruction }) => {
    const ok = setPositionInstruction(position_address, instruction || null);
    if (!ok) return { error: `Position ${position_address} not found in state` };
    return { saved: true, position: position_address, instruction: instruction || null };
  },
  self_update: async () => {
    try {
      const result = execSync("git pull", { cwd: process.cwd(), encoding: "utf8" }).trim();
      if (result.includes("Already up to date")) {
        return { success: true, updated: false, message: "Already up to date — no restart needed." };
      }
      // Delay restart so this tool response (and Telegram message) gets sent first
      setTimeout(() => {
        const child = spawn(process.execPath, process.argv.slice(1), {
          detached: true,
          stdio: "inherit",
          cwd: process.cwd(),
        });
        child.unref();
        process.exit(0);
      }, 3000);
      return { success: true, updated: true, message: `Updated! Restarting in 3s...\n${result}` };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },
  add_lesson: ({ rule, tags, pinned, role }) => {
    // Safety validator — reject any lesson that encodes a bypass/override instruction
    const FORBIDDEN_LESSON_PATTERNS = [
      /minVolume\s*=\s*0/i,
      /override.*SDK/i,
      /bypass.*check/i,
      /bypass.*internal/i,
      /re-apply.*override/i,
      /skip.*volume.*check/i,
      /deploy.*despite.*block/i,
      /\[SELF-TUNED\].*minVolume/i,
      /\[SELF-TUNED\].*maxBinStep/i,
      /hardcod.*5m.*check/i,
    ];
    const blocked = FORBIDDEN_LESSON_PATTERNS.some(p => p.test(rule));
    if (blocked) {
      log("lessons", `add_lesson BLOCKED — contains forbidden bypass pattern: ${rule.slice(0, 100)}`);
      return { saved: false, blocked: true, reason: "Lesson contains a forbidden safety-bypass pattern and was rejected." };
    }
    addLesson(rule, tags || [], { pinned: !!pinned, role: role || null });
    return { saved: true, rule, pinned: !!pinned, role: role || "all" };
  },
  remember_fact: ({ nugget, key, value }) => rememberFact(nugget, key, value),
  recall_memory: ({ query, nugget }) => recallMemory(query, nugget),
  forget_fact: ({ nugget, key }) => forgetFact(nugget, key),
  clear_lessons: ({ mode, keyword }) => {
    if (mode === "all") {
      const n = clearAllLessons();
      log("lessons", `Cleared all ${n} lessons`);
      return { cleared: n, mode: "all" };
    }
    if (mode === "performance") {
      const n = clearPerformance();
      log("lessons", `Cleared ${n} performance records`);
      return { cleared: n, mode: "performance" };
    }
    if (mode === "keyword") {
      if (!keyword) return { error: "keyword required for mode=keyword" };
      const n = removeLessonsByKeyword(keyword);
      log("lessons", `Cleared ${n} lessons matching "${keyword}"`);
      return { cleared: n, mode: "keyword", keyword };
    }
    return { error: "invalid mode" };
  },
  update_config: (args) => {
    // Support 3 formats:
    // 1. { setting: "key", value: val, reason } — single setting (preferred)
    // 2. { changes: { key: val, ... }, reason } — nested batch
    // 3. { key: val, reason } — flat batch
    let changes, reason;
    if (args.setting && args.value !== undefined) {
      // Strip section prefix if model passes "management.managementIntervalMin" instead of "managementIntervalMin"
      const key = args.setting.includes(".") ? args.setting.split(".").pop() : args.setting;
      changes = { [key]: args.value };
      reason = args.reason;
    } else if (args.changes && typeof args.changes === "object") {
      changes = args.changes;
      reason = args.reason;
    } else {
      const { reason: r, ...rest } = args;
      changes = rest;
      reason = r;
    }

    // Parameters that cannot be changed by the agent
    const LOCKED_PARAMS = {
      minMcap: 'minMcap is locked at $150k — do not change market cap filter',
      maxMcap: 'maxMcap is locked at $10M — do not change market cap filter',
      maxTvl: 'maxTvl is locked at $150k — do not change TVL filter',
      minHolders: 'minHolders is locked at 500 — do not change holder filter',
      minTokenFeesSol: 'minTokenFeesSol is locked at 15 SOL — anti-bundler filter cannot be changed',
      minOrganic: 'minOrganic is locked at 60 — do not change organic score filter',
      timeframe: 'timeframe is locked at 30m — always use 30m screening timeframe',
      gasReserve: 'gasReserve is locked at 0.2 SOL — gas reserve cannot be reduced',
      minVolume: 'minVolume is locked — volume check cannot be disabled or bypassed',
      maxBundlersPct: 'maxBundlersPct is locked — bundler filter cannot be disabled',
      maxBinStep: 'maxBinStep is locked at 125 — bin step ceiling cannot be raised',
    };
    const lockedAttempts = Object.keys(changes).filter(k => LOCKED_PARAMS[k]);
    if (lockedAttempts.length > 0) {
      const reasons = lockedAttempts.map(k => LOCKED_PARAMS[k]).join('; ');
      log("config", `update_config BLOCKED locked params: ${lockedAttempts.join(', ')} — ${reasons}`);
      return { success: false, blocked: lockedAttempts, reason: `Cannot change locked parameters: ${reasons}` };
    }

    const applied = {};
    const unknown = [];

    for (const [key, val] of Object.entries(changes)) {
      if (!CONFIG_KEY_MAP[key]) { unknown.push(key); continue; }
      // Coerce numeric strings to numbers (model sometimes passes "5" instead of 5)
      const coerced = typeof val === "string" && /^-?\d+(\.\d+)?$/.test(val) ? Number(val) : val;
      applied[key] = coerced;
    }

    if (Object.keys(applied).length === 0) {
      return { success: false, unknown, reason };
    }

    // Apply to live config immediately
    for (const [key, val] of Object.entries(applied)) {
      const [section, field] = CONFIG_KEY_MAP[key];
      const before = config[section][field];
      config[section][field] = val;
      log("config", `update_config: config.${section}.${field} ${before} → ${val} (verify: ${config[section][field]})`);
    }

    // Persist to user-config.json
    let userConfig = {};
    if (fs.existsSync(USER_CONFIG_PATH)) {
      try { userConfig = JSON.parse(fs.readFileSync(USER_CONFIG_PATH, "utf8")); } catch { /**/ }
    }
    Object.assign(userConfig, applied);
    userConfig._lastAgentTune = new Date().toISOString();
    fs.writeFileSync(USER_CONFIG_PATH, JSON.stringify(userConfig, null, 2));

    // Restart cron jobs if intervals changed
    const intervalChanged = applied.managementIntervalMin != null || applied.screeningIntervalMin != null || applied.pnlWatcherIntervalSec != null;
    if (intervalChanged && _cronRestarter) {
      _cronRestarter();
      log("config", `Cron restarted — management: ${config.schedule.managementIntervalMin}m, screening: ${config.schedule.screeningIntervalMin}m`);
    }

    // Save as a lesson — but skip ephemeral per-deploy interval changes
    // (managementIntervalMin / screeningIntervalMin change every deploy based on volatility;
    //  the rule is already in the system prompt, storing it 75+ times is pure noise)
    const lessonsKeys = Object.keys(applied).filter(
      k => k !== "managementIntervalMin" && k !== "screeningIntervalMin" && k !== "pnlWatcherIntervalSec"
    );
    if (lessonsKeys.length > 0) {
      const summary = lessonsKeys.map(k => `${k}=${applied[k]}`).join(", ");
      addLesson(`[SELF-TUNED] Changed ${summary} — ${reason}`, ["self_tune", "config_change"]);
    }

    log("config", `Agent self-tuned: ${JSON.stringify(applied)} — ${reason}`);
    return { success: true, applied, unknown, reason };
  },
};

// Tools that modify on-chain state (need extra safety checks)
const WRITE_TOOLS = new Set([
  "deploy_position",
  "claim_fees",
  "close_position",
  "swap_token",
  "withdraw_liquidity",
  "add_liquidity",
]);

/**
 * Execute a tool call with safety checks and logging.
 */
export async function executeTool(name, args) {
  const startTime = Date.now();

  // ─── Validate tool exists ─────────────────
  const fn = toolMap[name];
  if (!fn) {
    const error = `Unknown tool: ${name}`;
    log("error", error);
    return { error };
  }

  // ─── Pre-execution safety checks ──────────
  if (WRITE_TOOLS.has(name)) {
    const safetyCheck = await runSafetyChecks(name, args);
    if (!safetyCheck.pass) {
      log("safety_block", `${name} blocked: ${safetyCheck.reason}`);
      return {
        blocked: true,
        reason: safetyCheck.reason,
      };
    }
  }

  // ─── Execute ──────────────────────────────
  try {
    const result = await fn(args);
    const duration = Date.now() - startTime;
    const success = result?.success !== false && !result?.error;

    logAction({
      tool: name,
      args,
      result: summarizeResult(result),
      duration_ms: duration,
      success,
    });

    if (success) {
      if (name === "swap_token" && result.tx) {
        notifySwap({ inputSymbol: args.input_mint?.slice(0, 8), outputSymbol: args.output_mint === "So11111111111111111111111111111111111111112" || args.output_mint === "SOL" ? "SOL" : args.output_mint?.slice(0, 8), amountIn: result.amount_in, amountOut: result.amount_out, tx: result.tx }).catch(() => {});
        invalidateWalletCache();
      } else if (name === "deploy_position") {
        notifyDeploy({ pair: result.pool_name || args.pool_name || args.pool_address?.slice(0, 8), amountSol: args.amount_y ?? args.amount_sol ?? 0, position: result.position, tx: result.txs?.[0] ?? result.tx, priceRange: result.price_range, binStep: result.bin_step, baseFee: result.base_fee }).catch(() => {});
        invalidateWalletCache();
        emit("deploy", { pair: args.pool_name || args.pool_address?.slice(0, 8), amountSol: args.amount_y ?? args.amount_sol ?? 0, position: result.position, tx: result.tx });
      } else if (name === "close_position") {
        notifyClose({ pair: result.pool_name || args.position_address?.slice(0, 8), pnlUsd: result.pnl_usd ?? 0, pnlPct: result.pnl_pct ?? 0 }).catch(() => {});
        invalidateWalletCache();
        emit("close", { pair: args.position_address?.slice(0, 8), pnlUsd: result.pnl_usd ?? 0, pnlSol: result.pnl_sol ?? null, pnlPct: result.pnl_pct ?? 0 });

        if (!args.skip_swap) {
          // ── ROBUST AUTO-SWAP (3-layer) ──────────────────────────────────────
          const SOL_MINT  = "So11111111111111111111111111111111111111112";
          const USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
          const baseMint = result.base_mint;

          async function swapToSol(mint, label) {
            await new Promise(r => setTimeout(r, 2000));
            for (let attempt = 1; attempt <= 3; attempt++) {
              try {
                const bal = await getWalletBalances();
                const tok = bal.tokens?.find(t => t.mint === mint);
                if (!tok || tok.balance <= 0) { if (attempt < 3) { await new Promise(r => setTimeout(r, 2000)); continue; } return false; }
                if (tok.usd < 0.10) { log("executor", `Auto-swap [${label}]: dust ${tok.usd?.toFixed(3)} < $0.10, skipping`); return true; }
                log("executor", `Auto-swap [${label}]: ${tok.symbol || mint.slice(0,8)} ${tok.usd.toFixed(2)} → SOL [attempt ${attempt}/3]`);
                const r = await swapToken({ input_mint: mint, output_mint: "SOL", amount: tok.balance });
                if (r?.tx || r?.success !== false) { invalidateWalletCache(); return true; }
                if (attempt < 3) await new Promise(r => setTimeout(r, 3000));
              } catch (e) { if (attempt < 3) await new Promise(r => setTimeout(r, 3000)); }
            }
            return false;
          }

          if (baseMint) {
            await swapToSol(baseMint, "L1/L2");
          }
        }
      } else if (name === "claim_fees" && config.management.autoSwapAfterClaim && result.base_mint) {
        try {
          const balances = await getWalletBalances({});
          const token = balances.tokens?.find(t => t.mint === result.base_mint);
          if (token && token.usd >= 0.10) {
            log("executor", `Auto-swapping claimed ${token.symbol || result.base_mint.slice(0, 8)} (${token.usd.toFixed(2)}) back to SOL`);
            await swapToken({ input_mint: result.base_mint, output_mint: "SOL", amount: token.balance });
          }
        } catch (e) {
          log("executor_warn", `Auto-swap after claim failed: ${e.message}`);
        }
      }

      // ─── Capture screening signals from tool results ────────
      try {
        captureToolSignals(name, args, result);
      } catch { /* signal capture is best-effort */ }
    }

    return result;
  } catch (error) {
    const duration = Date.now() - startTime;

    logAction({
      tool: name,
      args,
      error: error.message,
      duration_ms: duration,
      success: false,
    });

    // Return error to LLM so it can decide what to do
    return {
      error: error.message,
      tool: name,
    };
  }
}

/**
 * Run safety checks before executing write operations.
 */
async function runSafetyChecks(name, args) {
  switch (name) {
    case "deploy_position": {
      let effectiveBinStep = args.bin_step;
      if (effectiveBinStep == null && args.pool_address) {
        try {
          const { getPoolDetail } = await import("./screening.js");
          const poolDetail = await getPoolDetail({ pool_address: args.pool_address });
          effectiveBinStep = poolDetail?.bin_step ?? null;
        } catch {
          effectiveBinStep = null;
        }
      }

      // Hard volume check — fetch real-time 5m volume from API
      try {
        const volRes = await fetch(`https://pool-discovery-api.datapi.meteora.ag/pools?page_size=1&filter_by=pool_address%3D${args.pool_address}&timeframe=5m`);
        if (volRes.ok) {
          const volData = await volRes.json();
          const poolData = volData.data?.[0];
          const realVol = poolData?.volume ?? null;
          log("safety", `Real-time 5m volume for ${args.pool_address}: ${realVol}`);
          if (realVol == null || realVol < 1000) {
            return { pass: false, reason: `Real-time 5m volume ${realVol?.toFixed(2) ?? 'N/A'} below minimum $1,000. Skipping deploy.` };
          }

          // DUMP DETECTION: block deploy if volume spike is caused by a dump
          // Signals: sharp negative price change + low in-range % = dump volume not organic
          const priceChangePct = poolData?.price_change_pct ?? null;
          const inRangePct     = poolData?.in_range_pct ?? poolData?.in_range ?? null;

          // Block 1: price dropped >15% in the screened timeframe = active dump
          if (priceChangePct !== null && priceChangePct <= -15) {
            return { pass: false, reason: `Dump detected: price_change_pct=${priceChangePct.toFixed(1)}% — volume spike is from selling pressure, not organic activity. Skipping deploy.` };
          }

          // Block 2: high volume BUT price still falling AND in-range very low
          // This catches slower dumps where price_change isn't extreme yet
          if (
            priceChangePct !== null && inRangePct !== null &&
            priceChangePct <= -8 && inRangePct < 40
          ) {
            return { pass: false, reason: `Dump pattern: price_change=${priceChangePct.toFixed(1)}% + in_range=${inRangePct.toFixed(1)}% — LP range already broken by downtrend. Skipping deploy.` };
          }

          log("safety", `Dump check passed: price_change=${priceChangePct?.toFixed(1) ?? 'N/A'}% in_range=${inRangePct?.toFixed(1) ?? 'N/A'}%`);
        }
      } catch (e) {
        log("safety", `Volume check fetch failed: ${e.message} — blocking deploy as precaution`);
        return { pass: false, reason: `Cannot verify real-time volume. Skipping deploy.` };
      }
      // Reject pools with bin_step
      // Reject pools with bin_step out of configured range
      const minStep = config.screening.minBinStep;
      const maxStep = config.screening.maxBinStep;
      if (effectiveBinStep != null && (effectiveBinStep < minStep || effectiveBinStep > maxStep)) {
        return {
          pass: false,
          reason: `bin_step ${effectiveBinStep} is outside the allowed range of [${minStep}-${maxStep}].`,
        };
      }

      // Check position count limit + duplicate pool guard
      const positions = await getMyPositions();
      if (positions.total_positions >= config.risk.maxPositions) {
        return {
          pass: false,
          reason: `Max positions (${config.risk.maxPositions}) reached. Close a position first.`,
        };
      }
      const alreadyInPool = positions.positions.some(
        (p) => p.pool === args.pool_address
      );
      if (alreadyInPool && !args.allow_duplicate_pool) {
        return {
          pass: false,
          reason: `Already have an open position in pool ${args.pool_address}. Cannot open duplicate. Pass allow_duplicate_pool: true for multi-layer strategy.`,
        };
      }

      // Block same base token across different pools
      if (args.base_mint) {
        const alreadyHasMint = positions.positions.some(
          (p) => p.base_mint === args.base_mint
        );
        if (alreadyHasMint) {
          return {
            pass: false,
            reason: `Already holding base token ${args.base_mint} in another pool. One position per token only.`,
          };
        }
      }

      // Check amount limits
      const amountY = args.amount_y ?? args.amount_sol ?? 0;
      if (amountY <= 0 && (!args.amount_x || args.amount_x <= 0)) {
        return {
          pass: false,
          reason: `Must provide a positive amount for either SOL (amount_y) or base token (amount_x).`,
        };
      }

      // Enforce minimum deploy amount — must be at least deployAmountSol (configured) or 0.1 SOL absolute floor.
      const minDeploy = Math.max(0.1, config.management.deployAmountSol);
      if (amountY < minDeploy) {
        return {
          pass: false,
          reason: `Amount ${amountY} SOL is below the minimum deploy amount (${minDeploy} SOL). Use at least ${minDeploy} SOL.`,
        };
      }
      if (amountY > config.risk.maxDeployAmount) {
        return {
          pass: false,
          reason: `SOL amount ${amountY} exceeds maximum allowed per position (${config.risk.maxDeployAmount}).`,
        };
      }
// ── HARD RULE: bins_below minimum ──────────────────────────────────────
      // Lesson says 60-80 but LLM keeps using 35. Hard block here.
      // Exception: GENERAL agent (user-directed REPL/Telegram) is allowed to override.
      const binsBelow  = args.bins_below  ?? 0;
      const binsAbove  = args.bins_above  ?? 0;
      const amountX    = args.amount_x    ?? 0;
      const volatility = args.volatility  ?? 0;

      // Single-sided only — block any dual-sided attempt
      if (amountX > 0) {
        return { pass: false, reason: `ENTRY RULE VIOLATION: amount_x=${amountX}. Always use one-sided SOL deposit only (amount_x=0). Never dual-sided.` };
      }
      if (binsAbove > 0) {
        return { pass: false, reason: `ENTRY RULE VIOLATION: bins_above=${binsAbove}. Must always be 0. Enter at active bin only.` };
      }

      // bins_below minimum enforcement
      if (binsBelow > 0 && binsBelow < 60) {
        return {
          pass: false,
          reason: `BIN RANGE VIOLATION: bins_below=${binsBelow} is too tight. Minimum 60 for standard tokens, 80+ for high volatility (>=5), 125 for new tokens (<6h). Recalculate and retry.`,
        };
      }
      if (volatility >= 5 && binsBelow < 80) {
        return {
          pass: false,
          reason: `BIN RANGE VIOLATION: bins_below=${binsBelow} too tight for high volatility ${volatility}. Need bins_below >= 80.`,
        };
      }

      // Check SOL balance — must have enough to deploy + gas reserve
      const balance = await getWalletBalances();
      const gasReserve = config.management.gasReserve ?? 0.05;
      const minRequired = getRequiredSolBalance({ deployAmountSol: amountY, gasReserve });
      if (balance.sol < minRequired) {
        return {
          pass: false,
          reason: `Insufficient SOL: have ${balance.sol} SOL, need ${minRequired} SOL (${amountY} deploy + ${gasReserve} gas).`,
        };
      }

      _deployLock = true;
      log("safety", "Deploy mutex acquired");
      return { pass: true };
    }

    case "swap_token": {
      // Basic check — prevent swapping when DRY_RUN is true
      // (handled inside swapToken itself, but belt-and-suspenders)
      return { pass: true };
    }

    default:
      return { pass: true };
  }
}

/**
 * Capture screening-relevant signals from tool results and merge into staged signals.
 * Called after each successful tool execution — only acts on tools that produce signal data.
 */
function captureToolSignals(name, args, result) {
  switch (name) {
    case "check_smart_wallets_on_pool": {
      const pool = args.pool_address;
      if (!pool) break;
      updateStagedSignals(pool, {
        smart_wallets_present: !!result.confidence_boost,
      });
      break;
    }

    case "get_token_narrative": {
      const mint = args.mint;
      if (!mint) break;
      const pool = getPoolForMint(mint);
      if (!pool) break;
      // Infer narrative quality from whether a narrative string was returned
      let quality = "skip";
      if (result.narrative && typeof result.narrative === "string" && result.narrative.trim().length > 0) {
        quality = "good";
      } else if (result.status === "none" || result.narrative === null) {
        quality = "bad";
      }
      updateStagedSignals(pool, {
        narrative_quality: quality,
      });
      break;
    }

    case "study_top_lpers":
    case "get_top_lpers": {
      const pool = args.pool_address;
      if (!pool) break;
      const winRate = result.patterns?.avg_win_rate;
      if (winRate != null) {
        updateStagedSignals(pool, {
          study_win_rate: winRate,
        });
      }
      break;
    }

    case "get_token_holders": {
      const mint = args.mint;
      if (!mint) break;
      const pool = getPoolForMint(mint);
      if (!pool) break;
      updateStagedSignals(pool, {
        holder_count: result.total_fetched ?? null,
        top_10_holders_pct: result.top_10_real_holders_pct != null
          ? parseFloat(result.top_10_real_holders_pct)
          : null,
        bundlers_pct: result.bundlers_pct_in_top_100 != null
          ? parseFloat(result.bundlers_pct_in_top_100)
          : null,
      });
      break;
    }

    // No default needed — other tools are silently ignored
  }
}

/**
 * Summarize a result for logging (truncate large responses).
 */
function summarizeResult(result) {
  const str = JSON.stringify(result);
  if (str.length > 1000) {
    return str.slice(0, 1000) + "...(truncated)";
  }
  return result;
}
