import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { getEffectiveMinSolToOpen } from "./runtime-helpers.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const USER_CONFIG_PATH = path.join(__dirname, "user-config.json");

const u = fs.existsSync(USER_CONFIG_PATH)
  ? JSON.parse(fs.readFileSync(USER_CONFIG_PATH, "utf8"))
  : {};

// Apply wallet/RPC from user-config if not already in env
if (u.rpcUrl)    process.env.RPC_URL            ||= u.rpcUrl;
if (u.walletKey) process.env.WALLET_PRIVATE_KEY ||= u.walletKey;
if (u.llmModel)  process.env.LLM_MODEL          ||= u.llmModel;
if (u.dryRun !== undefined) process.env.DRY_RUN ||= String(u.dryRun);

export const config = {
  // ─── Risk Limits ─────────────────────────
  risk: {
    maxPositions:    u.maxPositions    ?? 5,
    maxDeployAmount: u.maxDeployAmount ?? 50,
  },

  // ─── Pool Screening Thresholds ───────────
  screening: {
    minFeeActiveTvlRatio: u.minFeeActiveTvlRatio ?? 0.05,
    minTvl:            u.minTvl            ?? 5000,
    maxTvl:            u.maxTvl            ?? 150_000,
    minVolume:         u.minVolume         ?? 1000,
    minOrganic:        u.minOrganic        ?? 60,
    minHolders:        u.minHolders        ?? 500,
    minMcap:           u.minMcap           ?? 150_000,
    maxMcap:           u.maxMcap           ?? 10_000_000,
    minBinStep:        u.minBinStep        ?? 80,
    maxBinStep:        u.maxBinStep        ?? 125,
    maxVolatility:     u.maxVolatility     ?? 8,
    maxPriceChangePct: u.maxPriceChangePct ?? 300,
    timeframe:         u.timeframe         ?? "5m",
    category:          u.category          ?? "trending",
    minTokenFeesSol:   u.minTokenFeesSol   ?? 15,  // global fees paid (priority+jito tips). below = bundled/scam
    maxBundlersPct:    u.maxBundlersPct    ?? 30,  // max bot/bundler holders % (from Jupiter audit)
    maxTop10Pct:       u.maxTop10Pct       ?? 60,  // max top 10 holders concentration
    blockedLaunchpads: u.blockedLaunchpads ?? [],  // e.g. ["letsbonk.fun", "pump.fun"]
  },

  // ─── Position Management ────────────────
  management: {
    minClaimAmount:        u.minClaimAmount        ?? 5,
    autoSwapAfterClaim:    u.autoSwapAfterClaim    ?? true,
    outOfRangeBinsToClose: u.outOfRangeBinsToClose ?? 5,
    outOfRangeWaitMinutes: u.outOfRangeWaitMinutes ?? 30,
    minVolumeToRebalance:  u.minVolumeToRebalance  ?? 1000,
    emergencyPriceDropPct: u.emergencyPriceDropPct ?? -30,
    stopLossPct:           u.stopLossPct ?? -20,
    takeProfitFeePct:      u.takeProfitFeePct ?? 5,
    trailingTakeProfit:    u.trailingTakeProfit ?? true,
    trailingTriggerPct:    u.trailingTriggerPct ?? 3,
    trailingDropPct:       u.trailingDropPct ?? 1.5,
    minSolToOpen:          getEffectiveMinSolToOpen({
      minSolToOpen: u.minSolToOpen ?? 0.55,
      deployAmountSol: u.deployAmountSol ?? 0.5,
      gasReserve: u.gasReserve ?? 0.2,
    }),
    deployAmountSol:       u.deployAmountSol ?? 0.5,
    gasReserve:            u.gasReserve        ?? 0.2,   // always keep this much SOL for gas
    positionSizePct:       u.positionSizePct   ?? 0.35,  // % of deployable capital per position
    pnlUnit:               u.pnlUnit           ?? "sol", // "sol" or "usd" — how PnL is displayed
  },

  // ─── Strategy Mapping ───────────────────
  strategy: {
    strategy:   u.strategy   ?? "bid_ask",
    binsBelow:  u.binsBelow  ?? 69,  // activeBin - 69 to activeBin = 70 bins total (program max)
  },

  // ─── Scheduling ─────────────────────────
  schedule: {
    managementIntervalMin: u.managementIntervalMin ?? 10,
    screeningIntervalMin:  u.screeningIntervalMin  ?? 30,
    healthCheckIntervalMin: u.healthCheckIntervalMin ?? 60,
    pnlWatcherIntervalSec: u.pnlWatcherIntervalSec ?? 30,
  },

  // ─── LLM Settings ──────────────────────
  llm: {
    temperature: u.temperature ?? 0.373,
    maxTokens:   u.maxTokens   ?? 4096,
    maxSteps: u.maxSteps ?? 20,
    managementModel: u.managementModel ?? process.env.LLM_MODEL ?? "openai/gpt-oss-120b",
    screeningModel:  u.screeningModel  ?? process.env.LLM_MODEL ?? "openai/gpt-oss-120b",
    generalModel:    u.generalModel    ?? process.env.LLM_MODEL ?? "openai/gpt-oss-120b",
  },

  // ─── Web UI ───────────────────────────
  web: {
    port: parseInt(u.webPort || process.env.WEB_PORT || "3737", 10),
  },

  // ─── Darwinian Signal Weighting ─────────
  darwin: {
    enabled: u.darwinianWeights ?? false,
    windowDays: u.darwinianWindowDays ?? 60,
    boostFactor: u.darwinianBoostFactor ?? 1.05,
    decayFactor: u.darwinianDecayFactor ?? 0.95,
    weightFloor: u.darwinianWeightFloor ?? 0.3,
    weightCeiling: u.darwinianWeightCeiling ?? 2.5,
    minSamples: u.darwinianMinSamples ?? 10,
  },

  // ─── Autoresearch (ATLAS-inspired prompt optimization) ─────
  autoresearch: {
    enabled: u.autoresearch ?? false,
    minClosesPerTrial: u.autoresearchMinCloses ?? 7,
    improvementPct: u.autoresearchImprovementPct ?? 15,
    declinePct: u.autoresearchDeclinePct ?? 15,
    cooldownCloses: u.autoresearchCooldownCloses ?? 5,
    llmModel: u.autoresearchModel ?? "openai/gpt-5.4-nano",
  },

  // ─── Common Token Mints ────────────────
  tokens: {
    SOL:  "So11111111111111111111111111111111111111112",
    USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    USDT: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
  },
};

/**
 * Compute the optimal deploy amount for a given wallet balance.
 * Scales position size with wallet growth (compounding).
 */
export function computeDeployAmount(walletSol) {
  const reserve  = config.management.gasReserve      ?? 0.2;
  const pct      = config.management.positionSizePct ?? 0.35;
  const floor    = config.management.deployAmountSol;
  const ceil     = config.risk.maxDeployAmount;
  const deployable = Math.max(0, walletSol - reserve);
  const dynamic    = deployable * pct;
  const result     = Math.min(ceil, Math.max(floor, dynamic));
  return parseFloat(result.toFixed(2));
}

/**
 * Reload user-config.json and apply updated screening thresholds to the
 * in-memory config object. Called after threshold evolution so the next
 * agent cycle uses the evolved values without a restart.
 */
export function reloadScreeningThresholds() {
  if (!fs.existsSync(USER_CONFIG_PATH)) return;
  try {
    const fresh = JSON.parse(fs.readFileSync(USER_CONFIG_PATH, "utf8"));
    const s = config.screening;
    if (fresh.minFeeActiveTvlRatio != null) s.minFeeActiveTvlRatio = fresh.minFeeActiveTvlRatio;
    if (fresh.minOrganic     != null) s.minOrganic     = fresh.minOrganic;
    if (fresh.minHolders     != null) s.minHolders     = fresh.minHolders;
    if (fresh.minMcap        != null) s.minMcap        = fresh.minMcap;
    if (fresh.maxMcap        != null) s.maxMcap        = fresh.maxMcap;
    if (fresh.minTvl         != null) s.minTvl         = fresh.minTvl;
    if (fresh.maxTvl         != null) s.maxTvl         = fresh.maxTvl;
    if (fresh.minVolume      != null) s.minVolume      = fresh.minVolume;
    if (fresh.minBinStep     != null) s.minBinStep     = fresh.minBinStep;
    if (fresh.maxBinStep     != null) s.maxBinStep     = fresh.maxBinStep;
    if (fresh.maxVolatility  != null) s.maxVolatility  = fresh.maxVolatility;
    if (fresh.maxPriceChangePct != null) s.maxPriceChangePct = fresh.maxPriceChangePct;
    if (fresh.timeframe      != null) s.timeframe      = fresh.timeframe;
    if (fresh.category          != null) s.category          = fresh.category;
    if (fresh.maxBundlersPct    != null) s.maxBundlersPct    = fresh.maxBundlersPct;
    if (fresh.maxTop10Pct       != null) s.maxTop10Pct       = fresh.maxTop10Pct;
    if (fresh.blockedLaunchpads != null) s.blockedLaunchpads = fresh.blockedLaunchpads;
  } catch { /* ignore */ }
}
